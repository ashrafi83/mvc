<?php
include 'core/Config.php';
include 'core/App.php';
include 'core/Controller.php';
include 'core/Model.php';

new App();
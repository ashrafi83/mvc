<?php

class md_index extends Model
{
    public function __construct()
    {
        parent::__construct();
    }
}
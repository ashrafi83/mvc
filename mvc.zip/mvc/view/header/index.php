<header class="header">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-3 col-4 site-logo">
                <a href="<?php echo URL; ?>">
                    <img src="public/upload/img/akoritm-logo-header.png">
                </a>
            </div>
            <div class="menu col-lg-6 col-md-6 col-sm-6 col-4">
                <ul>
                    <li>
                        <a href="categories">دسته بندی</a>
                    </li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3 col-4" style="text-align: left;margin-top: 30px;">
                <a href="<?php echo URL.'profile'; ?>">حساب کاربری</a>
                <span> | </span>
                <a href="<?php echo URL.'shop'; ?>">فروشگاه</a>
            </div>
        </div>
    </div>
</header>
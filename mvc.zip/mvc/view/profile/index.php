<h5 class="text-center text-bold">
    <?php echo $data['user_name']; ?>
</h5>
<hr>